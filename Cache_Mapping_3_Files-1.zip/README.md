# Cache Mapping Techniques Simulator

A Python-based cache simulator demonstrating:

- Direct Mapping
- Fully Associative Mapping
- 2-Way Set-Associative Mapping
- Hit/Miss detection
- LRU replacement
- Hit ratio, miss ratio and AMAT calculation

## Run

```bash
python cache_simulator.py
```

## Sample memory addresses

`0, 4, 8, 16, 0, 20, 4, 24, 8, 28, 0, 16, 32, 4, 36, 0`

## Recommendation

For data-intensive processor workloads, set-associative mapping is generally a practical choice because it reduces conflict misses while keeping hardware complexity lower than fully associative mapping. The final choice should be based on measured workload results.
