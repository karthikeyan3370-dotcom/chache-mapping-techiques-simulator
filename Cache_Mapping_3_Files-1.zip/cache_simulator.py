from collections import deque

def direct_mapping(addresses, cache_size=16, block_size=4):
    lines = cache_size // block_size
    cache = [None] * lines
    hits = misses = 0
    output = []
    for address in addresses:
        block = address // block_size
        index = block % lines
        tag = block // lines
        if cache[index] == tag:
            hits += 1
            status = "HIT"
        else:
            misses += 1
            status = "MISS"
            cache[index] = tag
        output.append((address, status, index, tag, cache.copy()))
    return hits, misses, output

def fully_associative(addresses, cache_size=16, block_size=4):
    lines = cache_size // block_size
    cache = []
    hits = misses = 0
    output = []
    for address in addresses:
        block = address // block_size
        if block in cache:
            hits += 1
            status = "HIT"
            cache.remove(block)
            cache.append(block)
        else:
            misses += 1
            status = "MISS"
            if len(cache) >= lines:
                cache.pop(0)
            cache.append(block)
        output.append((address, status, block, cache.copy()))
    return hits, misses, output

def set_associative(addresses, cache_size=16, block_size=4, ways=2):
    lines = cache_size // block_size
    sets = lines // ways
    cache = [deque() for _ in range(sets)]
    hits = misses = 0
    output = []
    for address in addresses:
        block = address // block_size
        set_index = block % sets
        tag = block // sets
        current = cache[set_index]
        if tag in current:
            hits += 1
            status = "HIT"
            current.remove(tag)
            current.append(tag)
        else:
            misses += 1
            status = "MISS"
            if len(current) >= ways:
                current.popleft()
            current.append(tag)
        output.append((address, status, set_index, tag,
                       [list(s) for s in cache]))
    return hits, misses, output

def report(name, hits, misses, total, hit_time=1, miss_penalty=50):
    hit_ratio = hits / total * 100
    miss_ratio = misses / total * 100
    amat = hit_time + (misses / total) * miss_penalty
    print(f"\n{name}")
    print("-" * 30)
    print(f"Hits       : {hits}")
    print(f"Misses     : {misses}")
    print(f"Hit Ratio  : {hit_ratio:.2f}%")
    print(f"Miss Ratio : {miss_ratio:.2f}%")
    print(f"AMAT       : {amat:.2f} cycles")

if __name__ == "__main__":
    addresses = [0, 4, 8, 16, 0, 20, 4, 24, 8, 28, 0, 16, 32, 4, 36, 0]
    total = len(addresses)

    h, m, _ = direct_mapping(addresses)
    report("DIRECT MAPPING", h, m, total)

    h, m, _ = fully_associative(addresses)
    report("FULLY ASSOCIATIVE", h, m, total)

    h, m, _ = set_associative(addresses, ways=2)
    report("2-WAY SET ASSOCIATIVE", h, m, total)
